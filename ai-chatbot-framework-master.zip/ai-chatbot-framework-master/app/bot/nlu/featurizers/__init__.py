from app.bot.nlu.featurizers.spacy_featurizer import SpacyFeaturizer

__all__ = ["SpacyFeaturizer"]
