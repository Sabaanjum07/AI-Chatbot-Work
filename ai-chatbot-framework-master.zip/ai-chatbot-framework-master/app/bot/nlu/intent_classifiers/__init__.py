from .sklearn_intent_classifer import SklearnIntentClassifier

__all__ = ["SklearnIntentClassifier"]
